# airport-problem
Simulação de controle de tráfego aereo - pista unica
* Aviões esperando para aterrisar
* Aviões esperando para decolar
* Aviões esperando para taxiar
* Aviões estacionado
