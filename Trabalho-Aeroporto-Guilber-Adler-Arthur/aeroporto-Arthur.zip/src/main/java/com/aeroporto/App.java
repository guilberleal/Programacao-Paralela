package com.aeroporto;

import java.lang.Thread;

public class App {
    public static void main(String[] args) {
        int pistas = 2;

        if (args.length > 0) {
            pistas = Integer.parseInt(args[0]);
        }

        Aeroporto aeroporto = new Aeroporto(pistas);
        Thread aeroporto_thread = new Thread(aeroporto);
        aeroporto_thread.start();

        Turistas turistas = new Turistas(aeroporto);
        Thread turistas_thread = new Thread(turistas);
        turistas_thread.start();
    }
}
