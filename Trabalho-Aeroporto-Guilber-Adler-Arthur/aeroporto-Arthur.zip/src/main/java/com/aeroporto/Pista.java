package com.aeroporto;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

import java.util.Arrays;

public class Pista {
    // Número da pista
    int numero;

    Aeroporto aeroporto;

    // Avião que está autorizado pelo aeroporto a utilizar esta pista

    Aviao aviao_autorizado = null;

    // As filas de taxi são FIFO (o primeiro avião a entrar é o
    // primeiro a sair), e existe uma pra cada pista

    Queue<Aviao> fila_pra_pista = new ArrayDeque<>();
    Queue<Aviao> fila_pra_estacionamento = new ArrayDeque<>();

    ReentrantLock lock = new ReentrantLock();
    Condition condition = lock.newCondition();

    public Pista(Aeroporto aeroporto, int numero) {
        this.aeroporto = aeroporto;
        this.numero = numero;
    }

    public Aviao remover_fila_pra_pista() {
        synchronized (fila_pra_pista) {
            return fila_pra_pista.poll();
        }
    }

    public Aviao remover_fila_pra_estacionamento() {
        synchronized (fila_pra_estacionamento) {
            return fila_pra_estacionamento.poll();
        }
    }

    public void adicionar_fila_pra_pista(Aviao aviao) {
        synchronized (fila_pra_pista) {
            fila_pra_pista.add(aviao);
        }
    }

    public void adicionar_fila_pra_estacionamento(Aviao aviao) {
        synchronized (fila_pra_estacionamento) {
            fila_pra_estacionamento.add(aviao);
        }
    }

    public boolean aguardando_taxi() {
        synchronized (fila_pra_pista) {
            if (!fila_pra_pista.isEmpty()) {
                return true;
            }
        }

        synchronized (fila_pra_estacionamento) {
            if (!fila_pra_estacionamento.isEmpty()) {
                return true;
            }
        }

        return false;
    }

    public Aviao autorizar_taxi_pista() {
        if (lock.tryLock()) {
            try {
                if (aviao_autorizado != null) {
                    return null;
                }

                aviao_autorizado = remover_fila_pra_pista();

                return aviao_autorizado;
            } finally {
                condition.signalAll();
                lock.unlock();
            }
        } else {
            return null;
        }
    }

    public Aviao autorizar_taxi_estacionamento() {
        if (lock.tryLock()) {
            try {
                if (aviao_autorizado != null) {
                    return null;
                }

                aviao_autorizado = remover_fila_pra_estacionamento();

                return aviao_autorizado;
            } finally {
                condition.signalAll();
                lock.unlock();
            }
        } else {
            return null;
        }
    }

    public boolean autorizar(Aviao aviao) {
        if (lock.tryLock()) {
            try {
                if (aviao_autorizado != null) {
                    return false;
                }

                aviao_autorizado = aviao;

                return true;
            } finally {
                condition.signalAll();
                lock.unlock();
            }
        } else {
            return false;
        }
    }

    public void taxi_pra_estacionamento(Aviao aviao) {
        lock.lock();
        try {
            while (aviao != aviao_autorizado) {
                try {
                    condition.await();
                } catch (InterruptedException e) {
                }
            }

            System.out.printf("\n%s Avião %s taxiando pra estacionamento na pista %d%n", Util.hora(), aviao.nome,
                    numero);

            // Tempo de taxi
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }

            System.out.printf("\n%s Avião %s chegou no estacionamento%n", Util.hora(), aviao.nome, numero);
        } finally {
            condition.signalAll();
            lock.unlock();
        }
    }

    public void taxi_pra_decolar(Aviao aviao) {
        lock.lock();
        try {
            while (aviao != aviao_autorizado) {
                try {
                    condition.await();
                } catch (InterruptedException e) {
                }
            }

            System.out.printf("\n%s Avião %s taxiando pra decolar na pista %d%n", Util.hora(), aviao.nome,
                    numero);

            // Tempo de taxi
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }

            System.out.printf("\n%s Avião %s chegou na pista para decolar%n", Util.hora(), aviao.nome, numero);

            aeroporto.aviao_pra_decolar(aviao);
        } finally {
            condition.signalAll();
            lock.unlock();
        }
    }

    public void aterrissar(Aviao aviao) {
        lock.lock();
        try {
            while (aviao != aviao_autorizado) {
                try {
                    condition.await();
                } catch (InterruptedException e) {
                }
            }

            System.out.printf("\n%s Avião %s pousando na pista %d%n", Util.hora(), aviao.nome, numero);

            // Tempo de aterrissagem
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
            }

            System.out.printf("\n%s Avião %s pousou na pista %d%n", Util.hora(), aviao.nome, numero);

            aviao_autorizado = null;

            adicionar_fila_pra_estacionamento(aviao);
        } finally {
            condition.signalAll();
            lock.unlock();
        }
    }

    public void decolar(Aviao aviao) {
        lock.lock();
        try {
            System.out.printf("\n%s Avião %s pedindo permissão pra decolar (prioridade: %f).%n", Util.hora(),
                    aviao.nome, aviao.prioridade_decolar());

            while (aviao != aviao_autorizado) {
                try {
                    condition.await();
                } catch (InterruptedException e) {
                }
            }

            System.out.printf("\n%s Avião %s decolando na pista %d%n", Util.hora(), aviao.nome, numero);

            // Tempo de decolagem
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
            }

            System.out.printf("\n%s Avião %s decolou da pista %d%n", Util.hora(), aviao.nome, numero);

            aviao_autorizado = null;
        } finally {
            condition.signalAll();
            lock.unlock();
        }
    }
}
