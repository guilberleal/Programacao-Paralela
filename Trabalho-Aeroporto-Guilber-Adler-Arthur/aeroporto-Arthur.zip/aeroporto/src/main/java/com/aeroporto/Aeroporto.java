package com.aeroporto;

import java.util.PriorityQueue;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

import java.util.Arrays;

public class Aeroporto implements Runnable {
    Queue<Aviao> fila_aterrissagem;
    Queue<Aviao> fila_decolagem;

    Queue<Aviao> saindo_do_estacionamento;

    ArrayList<Pista> pistas;

    Object monitor_aterrissar = new Object();
    Aviao aviao_quer_aterrissar = null;

    Object monitor_decolar = new Object();
    Aviao aviao_quer_decolar = null;

    Object monitor_sair_estacionamento = new Object();
    Aviao aviao_quer_sair_estacionamento = null;

    Aeroporto(int num_pistas) {
        // Na fila de aterrissagem, a prioridade de cada avião depende de quanto
        // a empresa paga e quanto combustíve ele tem
        fila_aterrissagem = new PriorityQueue<Aviao>(new Comparator<Aviao>() {
            public int compare(Aviao a1, Aviao a2) {
                return Double.compare(a1.prioridade_aterrissar(), a2.prioridade_aterrissar());
            }
        });

        // Na fila de decolagem, a prioridade de cada avião depende só de quanto
        // a empresa paga
        fila_decolagem = new PriorityQueue<Aviao>(new Comparator<Aviao>() {
            public int compare(Aviao a1, Aviao a2) {
                return Double.compare(a1.prioridade_decolar(), a2.prioridade_decolar());
            }
        });

        saindo_do_estacionamento = new ArrayDeque<>();

        pistas = new ArrayList<>();

        for (int i = 0; i < num_pistas; i++) {
            pistas.add(new Pista(this, i));
        }

    }

    public Aviao ver_aviao_saindo_do_estacionamento() {
        synchronized (monitor_sair_estacionamento) {
            if (aviao_quer_sair_estacionamento == null) {
                return null;
            }

            Aviao novo_aviao = aviao_quer_sair_estacionamento;

            aviao_quer_sair_estacionamento = null;

            monitor_sair_estacionamento.notifyAll();

            return novo_aviao;
        }
    }

    public void sair_do_estacionamento(Aviao novo_aviao) {
        synchronized (monitor_sair_estacionamento) {
            while (aviao_quer_sair_estacionamento != null) {
                try {
                    monitor_sair_estacionamento.wait();
                } catch (InterruptedException e) {
                }
            }

            monitor_sair_estacionamento.notifyAll();

            aviao_quer_sair_estacionamento = novo_aviao;
        }
    }

    public Aviao ver_se_tem_aviao_pra_aterrissar() {
        synchronized (monitor_aterrissar) {
            if (aviao_quer_aterrissar == null) {
                return null;
            }

            Aviao novo_aviao = aviao_quer_aterrissar;

            aviao_quer_aterrissar = null;

            monitor_aterrissar.notifyAll();

            return novo_aviao;
        }
    }

    public void aviao_pra_aterrissar(Aviao novo_aviao) {
        synchronized (monitor_aterrissar) {
            while (aviao_quer_aterrissar != null) {
                try {
                    monitor_aterrissar.wait();
                } catch (InterruptedException e) {
                }
            }

            monitor_aterrissar.notifyAll();

            aviao_quer_aterrissar = novo_aviao;
        }
    }

    public Aviao ver_se_tem_aviao_pra_decolar() {
        synchronized (monitor_decolar) {
            if (aviao_quer_decolar == null) {
                return null;
            }

            Aviao novo_aviao = aviao_quer_decolar;

            aviao_quer_decolar = null;

            monitor_decolar.notifyAll();

            return novo_aviao;
        }
    }

    public void aviao_pra_decolar(Aviao novo_aviao) {
        synchronized (monitor_decolar) {
            while (aviao_quer_decolar != null) {
                try {
                    monitor_decolar.wait();
                } catch (InterruptedException e) {
                }
            }

            aviao_quer_decolar = novo_aviao;

            monitor_decolar.notifyAll();
        }
    }

    // Tenta autorizar um avião, retornando a pista que estava vaga (ou null se não
    // havia nenhuma)
    public Pista tentar_autorizar(Aviao aviao) {
        int pista_num = 0;

        for (pista_num = 0; pista_num < pistas.size(); pista_num++) {
            boolean conseguiu = pistas.get(pista_num).autorizar(aviao);

            // Conseguimos achar uma pista!
            if (conseguiu) {
                return pistas.get(pista_num);
            }
        }

        // Se não temos nenhuma pista livre, retornamos null
        return null;
    }

    public boolean aguardando_taxi() {
        for (Pista pista : pistas) {
            if (pista.aguardando_taxi()) {
                return true;
            }
        }
        return false;
    }

    public void run() {
        System.out.printf("%s Iniciando aeroporto com %d pistas\n", Util.hora(), pistas.size());

        while (true) {
            Aviao aviao_pra_aterrissar = ver_se_tem_aviao_pra_aterrissar();

            if (aviao_pra_aterrissar != null) {
                fila_aterrissagem.add(aviao_pra_aterrissar);
            }

            Aviao aviao_pra_decolar = ver_se_tem_aviao_pra_decolar();

            if (aviao_pra_decolar != null) {
                fila_decolagem.add(aviao_pra_decolar);
            }

            Aviao aviao_saindo_estacionamento = ver_aviao_saindo_do_estacionamento();

            if (aviao_saindo_estacionamento != null) {
                saindo_do_estacionamento.add(aviao_saindo_estacionamento);
            }

            if (!fila_aterrissagem.isEmpty()) {
                // Os aviões na fila de aterrissagem precisa ser processada
                // antes das demais pois possuem prioridade maior

                // O próximo avião a decolar é de maior prioridade desta fila
                Aviao proximo = fila_aterrissagem.element();

                // Tenta atribuir este avião à primeira pista livre que
                // encontrar
                Pista pista_livre = tentar_autorizar(proximo);

                if (pista_livre != null) {
                    // Deu certo! Primeiro, o avião da fila de aterrissagem
                    fila_aterrissagem.poll();

                    System.out.printf("\n%s Controle aéreo autorizando avião %s a aterrissar na pista %d%n",
                            Util.hora(), proximo.nome, pista_livre.numero);

                    // Informa ao avião em qual pista ele vai aterrissar
                    proximo.atribuir_pista(pista_livre);
                }
            } else if (!fila_decolagem.isEmpty()) {
                // Nota: só processamos a fila de decolagem se não tiver nenhum avião pra
                // pousar!

                // O próximo avião a aterrissar é de maior prioridade desta fila
                Aviao proximo = fila_decolagem.element();
                
                // Tenta atribuir este avião à pista que ele já está
                Pista pista = tentar_autorizar(proximo);
                // OBS: o acesso dessincronizado é válido pois a partir desse
                // ponto não existem mais escritas nessa variável (e portanto
                // não existe possibilidade de data race)
                //Pista pista = proximo.pista;

                if (pista != null) {
                    // Remove o avião da fila de decolagem
                    fila_decolagem.poll();

                    System.out.printf("\n%s Controle aéreo autorizando avião %s a decolar da pista %d%n", Util.hora(),
                            proximo.nome, pista.numero);
                }
            } else if (aguardando_taxi()) {
                for (Pista pista : pistas) {
                    Aviao proximo = pista.autorizar_taxi_pista();

                    if (proximo != null) {
                        System.out.printf(
                                "\n%s Controle aéreo autorizando taxi para decolagem do avião %s na pista %d%n",
                                Util.hora(), proximo.nome, pista.numero);
                    } else {
                        Aviao outro = pista.autorizar_taxi_estacionamento();

                        if (outro != null) {
                            System.out.printf(
                                    "\n%s Controle aéreo autorizando taxi saindo do estacionamento para avião %s na pista %d%n",
                                    Util.hora(), outro.nome, pista.numero);
                        }
                    }
                }
            } else if (!saindo_do_estacionamento.isEmpty()) {
                Aviao proximo = saindo_do_estacionamento.remove();

                // Escolhe uma pista aleatória para esse avião taxiar
                int pista_num = ThreadLocalRandom.current().nextInt(pistas.size());
                Pista pista = pistas.get(pista_num);

                pista.adicionar_fila_pra_pista(proximo);

                proximo.atribuir_pista(pista);
            }

        }
    }

}
