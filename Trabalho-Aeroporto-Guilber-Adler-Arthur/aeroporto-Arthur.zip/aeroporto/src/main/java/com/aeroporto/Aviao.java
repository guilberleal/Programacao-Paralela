package com.aeroporto;

import java.util.Arrays;

public class Aviao implements Runnable {
    Aeroporto aeroporto;

    String nome;
    String empresa;
    double combustivel;
    double combustivel_max;
    double peso;
    int passageiros;
    int passageiros_max;

    // Indica a prioridade de cada empresa ao tentar aterrissarou decolar
    double taxa_da_empresa;

    // Inicialmente, o avião não tem uma pista atribuída
    Pista pista = null;
    // Existe mensagem do aeroporto
    boolean msg_aeroporto = false;

    public Aviao(Aeroporto aeroporto, String nome, String empresa, double combustivel_max, double combustivel,
            double peso,
            int passageiros_max,
            int passageiros, double taxa_da_empresa) {
        this.aeroporto = aeroporto;

        // Características do avião
        this.nome = nome;
        this.empresa = empresa;
        this.combustivel_max = combustivel;
        this.combustivel = combustivel;
        this.peso = peso;
        this.passageiros_max = passageiros_max;
        this.passageiros = passageiros;

        this.taxa_da_empresa = taxa_da_empresa;

        System.out.println("\n---" + Util.hora() + "---\n" +
                "Novo avião\n" +
                "\n" +
                "Nome: " + nome + "\n" +
                "Empresa: " + empresa + "\n" +
                "Combustível: " + combustivel + " (max: " + combustivel_max + ") \n" +
                "Peso: " + peso + "\n" +
                "Passageiros: " + passageiros + " (max: " + passageiros_max + ") \n" +
                "--------------");

    }

    // A prioridade ao aterrissar é inversamente proporcional à quantidade de
    // combustível que o avião tem, e diretamente proporcional à taxa da empresa
    public double prioridade_aterrissar() {
        return taxa_da_empresa/combustivel;
    }

    // A prioridade ao decolar é simplesmente a taxa que a empresa cobra
    public double prioridade_decolar() {
        return taxa_da_empresa;
    }

    public synchronized void esperar_pista() {
        while (msg_aeroporto == false) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
        msg_aeroporto = false;
        notify();
    }

    public synchronized void atribuir_pista(Pista pista) {
        while (msg_aeroporto == true) {
            try {
                wait();
            } catch (InterruptedException e) {
            }
        }
        this.pista = pista;

        msg_aeroporto = true;
        notify();
    }

    public void run() {
        aeroporto.aviao_pra_aterrissar(this);

        esperar_pista();

        pista.aterrissar(this);

        pista.taxi_pra_estacionamento(this);

        System.out.printf("\n%s Avião %s estacionou e está reabastecendo.\n", Util.hora(), nome);

        double incremento_combustivel = Math.min(combustivel_max - combustivel, 2000.0);

        try {
            Thread.sleep(Math.round(incremento_combustivel));
        } catch (InterruptedException e) {
        }

        combustivel += incremento_combustivel;

        aeroporto.sair_do_estacionamento(this);

        esperar_pista();

        pista.taxi_pra_decolar(this);

        pista.decolar(this);
    }
}
