package com.aeroporto;

import java.util.concurrent.ThreadLocalRandom;
import java.lang.Thread;
import java.util.Arrays;

public class Turistas implements Runnable {
    Aeroporto aeroporto;

    // Nomes dos aviões
    String[] nomes = {
            "Frajola",
            "Piu-piu",
            "Pernalonga",
            "Patolino",
            "Ligeirinho",
            "Taz",
            "Wile E. Coyote",
            "Hortelino",
            "Marvin",
            "Gaguinho",
            "Pépe Le Gambá",
            "BOING 777",
            "FORÇAS AEREAS JATO",
            "JATO PARTICULAR",
    };

    Thread[] threads_avioes = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
    };

    public Turistas(Aeroporto aeroporto) {
        this.aeroporto = aeroporto;
    }

    public Aviao gerar_aviao_aleatorio() {
        // Esquece os aviões que já decolaram embora, pra que eles possam voltar
        for (int i = 0; i < threads_avioes.length; i++) {
            if (threads_avioes[i] != null && !threads_avioes[i].isAlive()) {
                threads_avioes[i] = null;
            }
        }

        boolean todos_estao_no_ar = Arrays.stream(threads_avioes).allMatch(thread -> thread != null);

        if (todos_estao_no_ar) {
            return null;
        }

        ThreadLocalRandom rng = ThreadLocalRandom.current();

        int aviao_indice;

        do {
            aviao_indice = rng.nextInt(nomes.length);
        } while (threads_avioes[aviao_indice] != null);

        double combustivel_max = rng.nextDouble(500, 5000);
        double combustivel = rng.nextDouble(20, combustivel_max);

        double peso = combustivel + 50000;

        int passageiros_max = rng.nextInt(100, 500);
        int passageiros = rng.nextInt(7, passageiros_max);

        double taxa_da_empresa = rng.nextDouble(750, 1500);

        Aviao aviao = new Aviao(aeroporto, nomes[aviao_indice], "ACME", combustivel_max, combustivel, peso,
                passageiros_max, passageiros, taxa_da_empresa);

        Thread aviao_thread = new Thread(aviao);
        aviao_thread.start();

        threads_avioes[aviao_indice] = aviao_thread;

        return aviao;
    }

    public void run() {
        while (true) {
            Aviao aviao = gerar_aviao_aleatorio();

            if (aviao == null) {
                System.out.println("\n---" + Util.hora() + "---\n" +
                        "teste.\n" +
                        "--------------");
                return;
            }

            try {
                Thread.sleep(ThreadLocalRandom.current().nextLong(600, 1000));
            } catch (InterruptedException e) {
            }
        }
    }
}
